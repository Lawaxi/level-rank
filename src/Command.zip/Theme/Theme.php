<?php

namespace Lawaxi\LevelRanks\Theme;

use Flarum\Database\AbstractModel;
use Flarum\Database\ScopeVisibilityTrait;

class Theme extends AbstractModel
{
    use ScopeVisibilityTrait;
}

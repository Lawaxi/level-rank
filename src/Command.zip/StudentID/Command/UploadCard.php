<?php

namespace Lawaxi\LevelRanks\StudentID\Command;

use Flarum\User\Command\UploadAvatar;

class UploadCard extends UploadAvatar
{
    //
}
